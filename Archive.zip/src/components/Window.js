import React from "react";

export default function Window() {
  return (
    <div className="window-top">
      <img src="window_elements.svg" className="window-elements" alt="Window buttons"></img>
    </div>
  );
}
