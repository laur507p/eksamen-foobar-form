import React from "react";
// import AddAndRemove from "./AddAndRemove";
// import Beers from "./pages/Beers";

export default function GetTotal(props){


    return (
    <p>Total: {total}</p>
    )
}